<form action="/update/<?php echo e($h->id); ?>"method="post">

    <?php echo csrf_field(); ?>
    
    <label for="name">Name:</label><br>
    <input type="text" id="Name" name="Name" value="<?php echo e($h->Name); ?>"><br>
    <label for="Class">Class</label><br>
    <input type="text" id="Class" name="Class" value="<?php echo e($h->Class); ?>"><br><br>
    <label for="marks">Marks</label><br>
    <input type="number" id="Marks" name="Marks" value="<?php echo e($h->Marks); ?>"><br><br>
    <input type="submit" value="Submit">
  </form> <?php /**PATH C:\xampp\htdocs\SSS\resources\views/edit.blade.php ENDPATH**/ ?>