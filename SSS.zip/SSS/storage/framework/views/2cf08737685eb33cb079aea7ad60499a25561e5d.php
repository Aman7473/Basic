
<table>
    <tr>
     <th>SrNo</th>
      <th>Name</th>
      <th>Class</th>
      <th>Marks</th>
      <th>Action</th>
    </tr>
    <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <tr>
        <td>
            <?php echo e($p->id); ?>

        
            </td>
        <td>
        <?php echo e($p->Name); ?>

    
        </td>
        <td>
            <?php echo e($p->Class); ?>

        
            </td>
            <td>
                <?php echo e($p->Marks); ?>

            
                </td>
                <td>
                    <button>
                   <a class="" href="/edit/<?php echo e($p->id); ?>">Edit</a>
                </button>
                    </td>
                    <td>
                     <form action="/delete/<?php echo e($p->id); ?>"method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                 <button type="submit">Delete
                    
                 </button>

                     </form>
                        
                     
                         </td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\xampp\htdocs\SSS\resources\views/show.blade.php ENDPATH**/ ?>