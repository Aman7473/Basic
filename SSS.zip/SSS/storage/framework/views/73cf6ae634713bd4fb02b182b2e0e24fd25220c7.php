

<br>
<br><br>

<center>
<form action="/login" method="post">
<?php echo csrf_field(); ?>


  </div>

  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required><br>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required><br>
<center>
    <button type="submit">Login</button>
</center>
  </div>

  
</form>
</center><?php /**PATH C:\xampp\htdocs\SSS\resources\views/login.blade.php ENDPATH**/ ?>