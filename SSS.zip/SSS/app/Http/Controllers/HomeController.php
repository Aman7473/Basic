<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;

class HomeController extends Controller
{
  public function index()
  {
    return view('login');
  }

 


  public function add(Request $req)
  {
    $data=new student();
    $data->Name=$req->Name;
    $data->Class=$req->Class;
    $data->Marks=$req->Marks;
    $data->save();
    return redirect('/show');
  }
  public function  show()
  {
    $a=student::get();

    return view('show',['a'=>$a]);
  }
  public function  edit($id)
  {

    $h=student::where('id' ,$id)->first();
    return view('edit',['h'=>$h]);
  }

  public function  update(Request $req ,$id)
  {
    $g=student::where('id',$id)->first();
    $g->Name=$req->Name;
    $g->Class=$req->Class;
    $g->Marks=$req->Marks;
    $g->save();
    return redirect('show');
  }








  
  public function  destroy($id)
  {

     $r=student:: where ('id',$id)->first();
       $r->delete();
       
        return  redirect('show');
  }


  public function login()
  {
    return view('create');
  }
 

}
