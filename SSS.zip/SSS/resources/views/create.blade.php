<form action="/insert"method="post">

    @csrf
    
    <label for="name">Name:</label><br>
    <input type="text" id="Name" name="Name" value=""><br>
    <label for="Class">Class</label><br>
    <input type="text" id="Class" name="Class" value=""><br><br>
    <label for="Marks">Marks</label><br>
    <input type="number" id="Marks" name="Marks" value=""><br><br>
    <input type="submit" value="Submit">
  </form> 